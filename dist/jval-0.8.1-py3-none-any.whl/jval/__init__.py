"""
Import the validate function from the main module.
"""

from .__main__ import validate
